﻿namespace _Project.CodeBase.Common
{
    public interface ISingleton<T>
    {
        public T Instance { get; protected set; }
    }
}