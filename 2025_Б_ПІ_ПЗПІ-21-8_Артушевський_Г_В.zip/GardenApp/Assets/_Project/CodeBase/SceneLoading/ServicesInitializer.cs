﻿using System;
using UnityEngine;

namespace _Project.CodeBase.SceneLoading
{
    public class ServicesInitializer : MonoBehaviour
    {
        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
        }
    }
}