﻿using UnityEngine;
using UnityEngine.SceneManagement;

namespace _Project.CodeBase.SceneLoading
{
    public class BootLoader : MonoBehaviour
    {
        public string SceneName = "MainMenu";

        private void Awake()
        {
            SceneManager.LoadScene(SceneName);
        }
    }
}