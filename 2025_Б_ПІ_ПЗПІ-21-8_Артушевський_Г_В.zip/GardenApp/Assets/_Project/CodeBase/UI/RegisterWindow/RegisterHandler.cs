﻿using _Project.CodeBase.Backend;
using TMPro;
using UnityEngine;

namespace _Project.CodeBase.UI.RegisterWindow
{
    public class RegisterHandler : MonoBehaviour
    {
        public TMP_InputField UsernameInput;
        public TMP_InputField EmailInput;
        public TMP_InputField PasswordInput;
        
        public void Register()
        {
            AccountManager.Instance.Register(EmailInput.text, UsernameInput.text, PasswordInput.text);
        }
    }
}