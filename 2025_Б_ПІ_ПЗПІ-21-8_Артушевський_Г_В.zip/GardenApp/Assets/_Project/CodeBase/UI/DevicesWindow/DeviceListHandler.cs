﻿using System;
using System.Collections.Generic;
using _Project.CodeBase.Backend;
using _Project.CodeBase.UI.GardenWindow;
using UnityEngine;

namespace _Project.CodeBase.UI.DevicesWindow
{
    public class DeviceListHandler : MonoBehaviour
    {
        public static DeviceListHandler Instance;

        public string CurrentGardenName;
        public Transform content;
        public GameObject prefab;

        private void Awake()
        {
            Instance = this;
            gameObject.SetActive(false);
        }
        
        
        private void Start()
        {
            LoadAllDevices();
        }

        public void LoadAllDevices()
        {
            DeviceManager.Instance.GetAllDeviceCodes(AccountManager.Instance.Token, CurrentGardenName);
        }

        public void UpdateList(List<string> devices)
        {
            for (int i = 0; i < content.childCount; i++)
            {
                GameObject.Destroy(content.GetChild(i).gameObject);
            }
            foreach (var device in devices)
            {
                var newGo = GameObject.Instantiate(prefab, content);
                newGo.GetComponent<DeviceElement>().Init(device, CurrentGardenName);
            }
        }
    }
}