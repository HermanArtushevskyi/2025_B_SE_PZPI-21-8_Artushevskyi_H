﻿using _Project.CodeBase.Backend;
using _Project.CodeBase.UI.GardenWindow;
using TMPro;
using UnityEngine;

namespace _Project.CodeBase.UI.DevicesWindow
{
    public class DeviceCreateHandler : MonoBehaviour
    {
        public TMP_InputField nameField;

        public void Register()
        {
            string deviceName = nameField.text;
            string gardenName = GardenInfoHandler.Instance.gardenLabel.text;
            
            DeviceManager.Instance.RegisterDevice(AccountManager.Instance.Token, gardenName, deviceName);
        }
    }
}