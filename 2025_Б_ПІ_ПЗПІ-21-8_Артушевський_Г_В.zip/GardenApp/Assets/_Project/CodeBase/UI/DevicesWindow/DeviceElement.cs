﻿using _Project.CodeBase.Backend;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace _Project.CodeBase.UI.DevicesWindow
{
    public class DeviceElement : MonoBehaviour
    {
        public TextMeshProUGUI _label;
        public Button _deleteBtn;
        private string _gardenName;

        public void Init(string deviceName, string gardenName)
        {
            _label.text = deviceName;
            _gardenName = gardenName;
        }

        public void Delete()
        {
            DeviceManager.Instance.DeleteDevice(AccountManager.Instance.Token, _gardenName, _label.text);
        }
    }
}