﻿using System;
using _Project.CodeBase.Backend;
using TMPro;
using UnityEngine;

namespace _Project.CodeBase.UI.ProfileWindow
{
    public class ProfileHandler : MonoBehaviour
    {
        public TextMeshProUGUI nameLabel;

        private void OnEnable()
        {
            nameLabel.text = AccountManager.Instance.Profile.name;
        }
    }
}