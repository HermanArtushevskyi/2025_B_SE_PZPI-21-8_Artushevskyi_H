﻿using _Project.CodeBase.Backend;
using TMPro;
using UnityEngine;

namespace _Project.CodeBase.UI.LoginWindow
{
    public class LoginHandler : MonoBehaviour
    {
        public TMP_InputField UsernameInput;
        public TMP_InputField PasswordInput;
        
        public void Login()
        {
            AccountManager.Instance.Login(UsernameInput.text, PasswordInput.text);
        }
    }
}