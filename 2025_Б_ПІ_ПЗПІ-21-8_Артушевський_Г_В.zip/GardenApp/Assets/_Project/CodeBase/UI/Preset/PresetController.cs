﻿using System;
using _Project.CodeBase.Backend;
using _Project.CodeBase.UI.GardenWindow;
using TMPro;
using Unity.Plastic.Newtonsoft.Json;
using UnityEngine;

namespace _Project.CodeBase.UI.Preset
{
    public class PresetController : MonoBehaviour
    {
        public static PresetController Instance;

        public TextMeshProUGUI label;
        public TMP_InputField ruleNameField;
        public TMP_InputField secondsField;
        public TMP_InputField argumentsField;
        public string presetName;
        
        private void Awake()
        {
            Instance = this;
            gameObject.SetActive(false);
        }

        public void Open(string presetType)
        {
            presetName = presetType;
            label.text = "Create " + presetType + " Rule";
            gameObject.SetActive(true);
        }
        
        public void Create()
        {
            int frequency = int.Parse(secondsField.text);
            string[] arguments = argumentsField.text.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string message = "";
            Message msg = new Message(ruleNameField.text, presetName, arguments);
            message = JsonConvert.SerializeObject(msg);
            RulesManager.Instance.AddRule(
                AccountManager.Instance.Token, GardenInfoHandler.Instance.gardenLabel.text,
                ruleNameField.text, message, frequency);
        }

        public class Message
        {
            public string Name;
            public string Type;
            public string[] Arguments;
            
            public Message(string name, string type, string[] arguments)
            {
                Name = name;
                Type = type;
                Arguments = arguments;
            }
        }
    }
}