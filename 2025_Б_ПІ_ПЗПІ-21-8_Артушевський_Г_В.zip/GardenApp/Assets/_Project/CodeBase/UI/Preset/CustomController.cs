﻿using _Project.CodeBase.Backend;
using _Project.CodeBase.UI.GardenWindow;
using TMPro;
using UnityEngine;

namespace _Project.CodeBase.UI.Preset
{
    public class CustomController : MonoBehaviour
    {
        public static CustomController Instance;

        public TMP_InputField ruleNameField;
        public TMP_InputField secondsField;
        public TMP_InputField messageField;
        
        private void Awake()
        {
            Instance = this;
            gameObject.SetActive(false);
        }
        
        public void Create()
        {
            int frequency = int.Parse(secondsField.text);
            string message = messageField.text;
            RulesManager.Instance.AddRule(
                AccountManager.Instance.Token, GardenInfoHandler.Instance.gardenLabel.text,
                ruleNameField.text, message, frequency);
        }
    }
}