﻿using System.Collections.Generic;
using _Project.CodeBase.Backend;
using _Project.CodeBase.UI.GardenWindow;
using ChartUtil;
using UnityEngine;

namespace _Project.CodeBase.UI.Charts
{
    public class TemperatureChart : MonoBehaviour
    {
        public static TemperatureChart Instance;

        private void Awake()
        {
            Instance = this;
            gameObject.SetActive(false);
        }

        public Chart chart;

        public void OnEnable()
        {
            TemperatureManager.Instance.GetAllData(AccountManager.Instance.Token, GardenInfoHandler.Instance.gardenLabel.text);
        }

        public void UpdateChart(List<TemperatureManager.Data> humidityData)
        {
            chart.chartData.series = new List<Series>();
            chart.chartData.categories = new List<string>();
            Series series = new Series
            {
                name = "Temperature",
                data = new List<Data>()
            };
            
            foreach (var data in humidityData)
            {
                chart.chartData.categories.Add($"{data.timestamp.Day}.{data.timestamp.Month} {data.timestamp.Hour}:{data.timestamp.Minute}");
                series.data.Add(new Data(data.value));
            }
            
            chart.chartData.series.Add(series);
            chart.UpdateChart();
        }
    }
}