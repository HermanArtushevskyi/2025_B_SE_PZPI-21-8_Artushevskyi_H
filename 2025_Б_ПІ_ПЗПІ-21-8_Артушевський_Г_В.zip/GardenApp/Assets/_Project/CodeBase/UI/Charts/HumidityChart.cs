﻿using System;
using System.Collections.Generic;
using _Project.CodeBase.Backend;
using _Project.CodeBase.UI.GardenWindow;
using ChartUtil;
using UnityEngine;

namespace _Project.CodeBase.UI.Charts
{
    public class HumidityChart : MonoBehaviour
    {
        public static HumidityChart Instance;

        private void Awake()
        {
            Instance = this;
            gameObject.SetActive(false);
        }

        public Chart chart;

        public void OnEnable()
        {
            HumidityManager.Instance.GetAllData(AccountManager.Instance.Token, GardenInfoHandler.Instance.gardenLabel.text);
            
        }

        public void UpdateChart(List<HumidityManager.Data> humidityData)
        {
            chart.chartData.series = new List<Series>();
            chart.chartData.categories = new List<string>();
            Series series = new Series
            {
                name = "Humidity",
                data = new List<Data>()
            };
            
            foreach (var data in humidityData)
            {
                chart.chartData.categories.Add($"{data.timestamp.Day}.{data.timestamp.Month} {data.timestamp.Hour}:{data.timestamp.Minute}");
                series.data.Add(new Data(data.humidityValue));
            }
            
            chart.chartData.series.Add(series);
            chart.UpdateChart();
        }
    }
}