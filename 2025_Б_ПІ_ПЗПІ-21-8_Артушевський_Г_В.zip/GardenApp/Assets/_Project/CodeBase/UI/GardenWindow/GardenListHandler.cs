﻿using System;
using System.Collections.Generic;
using _Project.CodeBase.Backend;
using UnityEngine;
using UnityEngine.UI;

namespace _Project.CodeBase.UI.GardenWindow
{
    public class GardenListHandler : MonoBehaviour
    {
        public static GardenListHandler Instance;
        
        public Transform content;
        public GameObject prefab;

        private void Awake()
        {
            GardenManager.Instance.GetAllGardens(AccountManager.Instance.Token);
            Instance = this;
        }

        private void Start()
        {
            LoadAllGardens();
        }

        public void LoadAllGardens()
        {
            GardenManager.Instance.GetAllGardens(AccountManager.Instance.Token);
        }

        public void UpdateList(List<GardenManager.GardenData> gardens)
        {
            for (int i = 0; i < content.childCount; i++)
            {
                GameObject.Destroy(content.GetChild(i).gameObject);
            }
            foreach (var garden in gardens)
            {
                var newGo = GameObject.Instantiate(prefab, content);
                newGo.GetComponent<GardenElement>().Init(garden.name);
            }
        }
    }
}