﻿using _Project.CodeBase.Backend;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace _Project.CodeBase.UI.GardenWindow
{
    public class GardenElement : MonoBehaviour
    {
        public TextMeshProUGUI _text;
        public Button _viewBtn;
        public Button _deleteBtn;

        public void Init(string elementName)
        {
            _text.text = elementName;
        }

        public void View()
        {
            GardenInfoHandler.Instance.gameObject.SetActive(true);
            GardenInfoHandler.Instance.Init(_text.text);
        }

        public void Delete()
        {
            GardenManager.Instance.DeleteGarden(_text.text, AccountManager.Instance.Token);
        }
    }
}