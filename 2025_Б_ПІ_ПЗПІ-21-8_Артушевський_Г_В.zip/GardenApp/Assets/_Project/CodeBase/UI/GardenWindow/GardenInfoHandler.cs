﻿using _Project.CodeBase.UI.DevicesWindow;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace _Project.CodeBase.UI.GardenWindow
{
    public class GardenInfoHandler : MonoBehaviour
    {
        public static GardenInfoHandler Instance;

        public TextMeshProUGUI gardenLabel;
        public Button devicesBtn;
        public Button temperatureBtn;
        public Button humidityBtn;
        public Button lightBtn;
        public Button automatizationsBtn;
        public Button removeBtn;

        private void Awake()
        {
            Instance = this;
            gameObject.SetActive(false);
        }

        public void Init(string gardenName)
        {
            gardenLabel.text = gardenName;
            DeviceListHandler.Instance.CurrentGardenName = gardenName;
        }
    }
}