﻿using _Project.CodeBase.Backend;
using TMPro;
using UnityEngine;

namespace _Project.CodeBase.UI.GardenWindow
{
    public class CreateGardenHandler : MonoBehaviour
    {
        public TMP_InputField gardenNameInput;
        
        public void CreateGarden()
        {
            string gardenName = gardenNameInput.text.Trim();
            if (string.IsNullOrEmpty(gardenName))
            {
                Debug.LogError("Garden name cannot be empty.");
                return;
            }

            GardenManager.Instance.CreateGarden(gardenName, AccountManager.Instance.Token);
        }
    }
}