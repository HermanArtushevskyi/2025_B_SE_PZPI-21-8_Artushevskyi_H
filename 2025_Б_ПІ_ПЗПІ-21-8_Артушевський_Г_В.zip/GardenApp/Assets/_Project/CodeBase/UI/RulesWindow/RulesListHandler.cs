﻿using System;
using System.Collections.Generic;
using _Project.CodeBase.Backend;
using _Project.CodeBase.UI.GardenWindow;
using UnityEngine;

namespace _Project.CodeBase.UI.RulesWindow
{
    public class RulesListHandler : MonoBehaviour
    {
        public static RulesListHandler Instance;

        public Transform content;
        public GameObject prefab;

        private void Awake()
        {
            Instance = this;
            RulesManager.Instance.GetAllRules(AccountManager.Instance.Token, GardenInfoHandler.Instance.gardenLabel.text);
            gameObject.SetActive(false);
        }

        private void Start()
        {
            LoadAllRules();
        }

        public void LoadAllRules()
        {
            RulesManager.Instance.GetAllRules(AccountManager.Instance.Token, GardenInfoHandler.Instance.gardenLabel.text);
        }
        
        public void UpdateList(List<ProcessData> processes)
        {
            for (int i = 0; i < content.childCount; i++)
            {
                GameObject.Destroy(content.GetChild(i).gameObject);
            }
            foreach (var process in processes)
            {
                var newGo = GameObject.Instantiate(prefab, content);
                newGo.GetComponent<RuleElement>().Init(process.name);
            }
        }
    }
}