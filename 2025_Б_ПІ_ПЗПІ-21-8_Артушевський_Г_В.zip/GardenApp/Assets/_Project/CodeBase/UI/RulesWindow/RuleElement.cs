﻿using _Project.CodeBase.Backend;
using _Project.CodeBase.UI.GardenWindow;
using TMPro;
using UnityEngine;

namespace _Project.CodeBase.UI.RulesWindow
{
    public class RuleElement : MonoBehaviour
    {
        public TextMeshProUGUI Label;

        public void Init(string ruleName)
        {
            Label.text = ruleName;
        }

        public void Delete()
        {
            RulesManager.Instance.DeleteRule(AccountManager.Instance.Token, GardenInfoHandler.Instance.gardenLabel.text, Label.text);
        }
    }
}