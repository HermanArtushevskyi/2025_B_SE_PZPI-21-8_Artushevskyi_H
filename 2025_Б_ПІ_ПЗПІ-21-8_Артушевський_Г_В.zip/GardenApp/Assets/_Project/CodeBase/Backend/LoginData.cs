﻿using System;

namespace _Project.CodeBase.Backend
{
    [Serializable]
    public class LoginData
    {
        public string Username;
        public string Password;
    }

    [Serializable]
    public class RegisterData
    {
        public string Username;
        public string Email;
        public string Password;
    }
}