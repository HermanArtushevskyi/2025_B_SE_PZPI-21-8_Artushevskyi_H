﻿using System;
using System.Collections.Generic;
using _Project.CodeBase.UI.Charts;
using Unity.Plastic.Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Networking;

namespace _Project.CodeBase.Backend
{
    public class LightManager : MonoBehaviour
    {
        public static LightManager Instance;

        public BackendConfig Config;
        
        private const string URL = "/api/DeviceReport/lightlevel?gardenName=";
        
        private void Awake()
        {
            Instance = this;
        }

        public void GetAllData(string token, string gardenName)
        {
            var request = UnityWebRequest.Get(Config.Host + URL + gardenName);
            request.SetRequestHeader("token", token);
            request.SendWebRequest().completed += (asyncOperation) =>
            {
                if (request.result == UnityWebRequest.Result.Success)
                {
                    var jsonResponse = request.downloadHandler.text;
                    var humidityData = JsonConvert.DeserializeObject<List<Data>>(jsonResponse);
                    LightChart.Instance.UpdateChart(humidityData);
                }
                else
                {
                    Debug.LogError("Failed to fetch light data: " + request.error);
                }
            };
        }

        [Serializable]
        public class Data
        {
            public int id;
            public string deviceCode;
            public float value;
            public DateTime timestamp;
        }
    }
}