﻿using System;
using System.Collections.Generic;
using _Project.CodeBase.UI.DevicesWindow;
using Unity.Plastic.Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Networking;

namespace _Project.CodeBase.Backend
{
    public class DeviceManager : MonoBehaviour
    {
        public static DeviceManager Instance;
        public BackendConfig Config;
        public List<string> DeviceCodes;
        private UnityWebHelpers _helpers;

        private const string GetDevicesURL = "/api/Device/codes?gardenName=";
        private const string DeleteDeviceURL = "/api/Device/unregister?gardenName=";
        private const string RegisterDeviceURL = "/api/Device/register?gardenName=";
        
        private void Awake()
        {
            Instance = this;
            DeviceCodes = new();
            _helpers = new(Config.Host);
        }

        public List<string> GetAllDeviceCodes(string token, string gardenName)
        {
            var request = UnityWebRequest.Get(Config.Host + GetDevicesURL + gardenName);
            request.SetRequestHeader("token", token);
            request.SendWebRequest().completed += (asyncOperation) =>
            {
                var jsonResponse = request.downloadHandler.text;
                List<string> deviceCodes = JsonConvert.DeserializeObject<List<string>>(jsonResponse);
                DeviceCodes = deviceCodes;
                DeviceListHandler.Instance.UpdateList(deviceCodes);
            };
            return DeviceCodes;
        }

        public void DeleteDevice(string token, string gardenName, string deviceCode)
        {
            var request = UnityWebRequest.Get(Config.Host + DeleteDeviceURL + gardenName);
            request.SetRequestHeader("token", token);
            request.SetRequestHeader("deviceCode", deviceCode);
            request.SendWebRequest();
            DeviceCodes.Remove(deviceCode);
            DeviceListHandler.Instance.UpdateList(DeviceCodes);
        }

        public void RegisterDevice(string token, string gardenName, string deviceCode)
        {
            var request = UnityWebRequest.Get(Config.Host + RegisterDeviceURL + gardenName);
            request.SetRequestHeader("token", token);
            request.SetRequestHeader("deviceCode", deviceCode);
            request.SendWebRequest();
        }

        [Serializable]
        public class DeleteDeviceData
        {
            public string code;
        }

        [Serializable]
        public class AllDevicesData
        {
            public List<string> codes;
        }
    }
}