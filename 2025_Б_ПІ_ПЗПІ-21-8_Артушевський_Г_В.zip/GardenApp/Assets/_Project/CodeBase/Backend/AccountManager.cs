﻿using System.Collections;
using _Project.CodeBase.Common;
using UnityEngine;
using UnityEngine.Networking;

namespace _Project.CodeBase.Backend
{
    public class AccountManager : MonoBehaviour
    {
        public static AccountManager Instance { get; private set; }
        
        public Profile Profile { get; private set; }
        public BackendConfig Config;
        public string Token => PlayerPrefs.GetString(TokenKey, string.Empty);
        private UnityWebHelpers _helpers;
        
        private const string LoginUrl = "/User/login";
        private const string RegisterUrl = "/User/register";
        private const string GetProfileUrl = "/User/getprofile?token=";
        private const string TokenKey = "Token";


        public void Awake()
        {
            Instance = this;
            Profile = new Profile();
            _helpers = new UnityWebHelpers(Config.Host);
        }
        
        public void Login(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                throw new System.ArgumentException("Name and email cannot be empty.");
            }
            
            var data = new LoginData()
            {
                Username = email,
                Password = password
            };
            
            var request = _helpers.CreateApiPostRequest(LoginUrl, data);
            var operation = request.SendWebRequest();
            operation.completed += (asyncOperation) =>
            {
                if (request.result == UnityWebRequest.Result.Success)
                {
                    var response = request.downloadHandler.text;
                    response = response.Trim('"', '\'', '\"');
                    PlayerPrefs.SetString(TokenKey, response);
                    StartCoroutine(GetProfileCoroutine(response));
                }
                else
                {
                    Debug.LogError($"Login failed: {request.error}");
                }
            };
        }
        
        public void Register(string email, string userName, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                throw new System.ArgumentException("Name and email cannot be empty.");
            }
            
            var data = new RegisterData()
            {
                Username = userName,
                Email = email,
                Password = password
            };
            
            var request = _helpers.CreateApiPostRequest(RegisterUrl, data);
            var operation = request.SendWebRequest();
            operation.completed += (asyncOperation) =>
            {
                if (request.result == UnityWebRequest.Result.Success)
                {
                    var response = request.downloadHandler.text;
                    response = response.Trim('"', '\'', '\"');
                    PlayerPrefs.SetString(TokenKey, response);
                }
                else
                {
                    Debug.LogError($"Register failed: {request.error}");
                }
            };
        }

        private IEnumerator GetProfileCoroutine(string token)
        {
            yield return new WaitForSecondsRealtime(0.5f);
            var requestProfile = UnityWebRequest.Get(Config.Host + GetProfileUrl + token);
            requestProfile.SendWebRequest().completed += (profileOperation) =>
            {
                if (requestProfile.result == UnityWebRequest.Result.Success)
                {
                    Profile = JsonUtility.FromJson<Profile>(requestProfile.downloadHandler.text);
                    Debug.Log($"Login successful: {Profile.name}");
                }
                else
                {
                    Debug.LogError($"Failed to get profile: {requestProfile.error}");
                }
            };

        }
    }
}