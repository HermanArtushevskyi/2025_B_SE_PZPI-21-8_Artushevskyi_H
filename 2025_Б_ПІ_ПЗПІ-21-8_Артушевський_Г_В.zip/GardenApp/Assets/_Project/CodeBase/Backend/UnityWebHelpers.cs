﻿using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace _Project.CodeBase.Backend
{
    public class UnityWebHelpers
    {
        public string BaseUrl { get; private set; }
        
        public UnityWebHelpers(string baseUrl)
        {
            BaseUrl = baseUrl;
        }
        
        public UnityWebRequest CreateApiGetRequest(string actionUrl, object body = null)
        {
            return CreateApiRequest(BaseUrl + actionUrl, UnityWebRequest.kHttpVerbGET, body);
        }

        public UnityWebRequest CreateApiDeleteRequest(string actionUrl, object body = null)
        {
            return CreateApiRequest(BaseUrl + actionUrl, UnityWebRequest.kHttpVerbDELETE, body);
        }

        public UnityWebRequest CreateApiPostRequest(string actionUrl, object body = null)
        {
            return CreateApiRequest(BaseUrl + actionUrl, UnityWebRequest.kHttpVerbPOST, body);
        }

        UnityWebRequest CreateApiRequest(string url, string method, object body)
        {
            string bodyString = null;
            if (body is string)
            {
                bodyString = (string)body;
            }
            else if (body != null)
            {
                bodyString = JsonUtility.ToJson(body);
            }

            var request = new UnityWebRequest();
            request.url = url;
            request.method = method;
            request.downloadHandler = new DownloadHandlerBuffer();
            request.uploadHandler = new UploadHandlerRaw(string.IsNullOrEmpty(bodyString) ? null : Encoding.UTF8.GetBytes(bodyString));
            request.SetRequestHeader("Accept", "application/json");
            request.SetRequestHeader("Content-Type", "application/json");
            request.timeout = 60;
            return request;
        }
    }
}