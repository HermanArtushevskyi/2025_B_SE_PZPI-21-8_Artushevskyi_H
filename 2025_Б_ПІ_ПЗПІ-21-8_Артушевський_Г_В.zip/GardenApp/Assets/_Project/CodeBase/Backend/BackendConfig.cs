﻿using UnityEngine;

namespace _Project.CodeBase.Backend
{
    [UnityEngine.CreateAssetMenu(fileName = "BackendConfig", menuName = "Backend/Config", order = 0)]
    public class BackendConfig : ScriptableObject
    {
        public string Path;
        public int Port;
        public string Host => $"{Path}:{Port}";
    }
}