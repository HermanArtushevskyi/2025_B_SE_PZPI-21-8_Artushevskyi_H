﻿using System;

namespace _Project.CodeBase.Backend
{
    [Serializable]
    public class GardenCreateData
    {
        public string name;
        public string token;
    }
}