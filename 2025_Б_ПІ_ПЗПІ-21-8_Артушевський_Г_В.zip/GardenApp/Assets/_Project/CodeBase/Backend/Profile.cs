﻿using _Project.CodeBase.Common;

namespace _Project.CodeBase.Backend
{
    public class Profile
    {
        public string name;
        public string email;
    }
}