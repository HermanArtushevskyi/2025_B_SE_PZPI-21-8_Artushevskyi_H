﻿using System;
using System.Collections.Generic;
using System.Linq;
using _Project.CodeBase.UI.RulesWindow;
using Unity.Plastic.Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Networking;

namespace _Project.CodeBase.Backend
{
    public class RulesManager : MonoBehaviour
    {
        public static RulesManager Instance;

        public BackendConfig Config;
        private List<ProcessData> Data;
        private UnityWebHelpers _helpers;

        private const string GET_ALL_URL = "/api/Rules?gardenName=";
        private const string DELETE_URL = "/api/Rules/deleterule?gardenName=";
        private const string ADD_URL = "/api/Rules?gardenName=";
        
        private void Awake()
        {
            Instance = this;
            _helpers = new(Config.Host);
            Data = new();
        }

        public List<ProcessData> GetAllRules(string token, string gardenName)
        {
            var request = UnityWebRequest.Get(Config.Host + GET_ALL_URL + gardenName);
            request.SetRequestHeader("token", token);
            request.SendWebRequest().completed += (op) =>
            {
                if (request.result == UnityWebRequest.Result.Success)
                {
                    Data = JsonConvert.DeserializeObject<List<ProcessData>>(request.downloadHandler.text);
                    RulesListHandler.Instance.UpdateList(Data);
                }
            };

            return Data;
        }

        public void DeleteRule(string token, string gardenName, string ruleName)
        {
            var request = UnityWebRequest.Get(Config.Host + DELETE_URL + gardenName + "&ruleName=" + ruleName);
            request.SetRequestHeader("token", token);
            Data.Remove(Data.First(r => r.name == ruleName));
            RulesListHandler.Instance.UpdateList(Data);
            request.SendWebRequest();
        }

        public void AddRule(string token, string gardenName, string ruleName, string message, int frequency)
        {
            var data = new ProcessCreateData();
            data.name = ruleName;
            data.message = message;
            data.frequency = frequency;
            data.startTime = DateTime.Now;

            var request = _helpers.CreateApiPostRequest(ADD_URL + gardenName, data);
            request.SetRequestHeader("token", token);
            request.SendWebRequest();
        }
    }
    
    [Serializable]
    public class ProcessData
    {
        public string name;
        public int gardenId;
        public int frequency;
        public DateTime startTime;
    }

    [Serializable]
    public class ProcessCreateData
    {
        public string name;
        public int gardenId;
        public string message;
        public int frequency;
        public DateTime startTime;
    }
}