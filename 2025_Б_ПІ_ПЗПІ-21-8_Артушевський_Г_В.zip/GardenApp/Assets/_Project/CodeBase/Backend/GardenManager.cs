﻿using System;
using System.Collections.Generic;
using System.Linq;
using _Project.CodeBase.UI.GardenWindow;
using Unity.Plastic.Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Networking;

namespace _Project.CodeBase.Backend
{
    public class GardenManager : MonoBehaviour
    {
        public static GardenManager Instance;

        public BackendConfig Config;
        public List<GardenData> AllGardens;
        private UnityWebHelpers _helpers;

        private const string CreateURL = "/Garden/create";
        private const string GetAllGardensURL = "/Garden/gardens";
        private const string DeleteGardensURL = "/Garden/remove";

        private void Awake()
        {
            Instance = this;
            AllGardens = new();
            _helpers = new(Config.Host);
        }

        public void CreateGarden(string gardenName, string token)
        {
            var data = new GardenCreateData()
            {
                name = gardenName,
                token = token
            };

            var request = _helpers.CreateApiPostRequest(CreateURL, data);
            var operation = request.SendWebRequest();
        }

        public List<GardenData> GetAllGardens(string token)
        {
            var request = UnityWebRequest.Get(Config.Host + GetAllGardensURL);
            request.SetRequestHeader("token", token);
            request.SendWebRequest().completed += (op) =>
            {
                if (request.result == UnityWebRequest.Result.Success)
                {
                    AllGardens = JsonConvert.DeserializeObject<List<GardenData>>(request.downloadHandler.text);
                    GardenListHandler.Instance.UpdateList(AllGardens);
                }
            };

            return AllGardens;
        }

        public void DeleteGarden(string gardenName, string token)
        {
            var data = new DeleteGardenData()
            {
                name = gardenName,
                token = token
            };

            AllGardens.Remove(AllGardens.Where(g => g.name == gardenName).First());
            GardenListHandler.Instance.UpdateList(AllGardens);
            var request = _helpers.CreateApiPostRequest(DeleteGardensURL, data);
            request.SendWebRequest();
        }

        [Serializable]
        public class GardenData
        {
            public int id;
            public string name;
            public int ownerId;
        }

        [Serializable]
        public class DeleteGardenData
        {
            public string name;
            public string token;
        }
    }
}